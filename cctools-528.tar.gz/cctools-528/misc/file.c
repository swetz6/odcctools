/*
 * Copyright (c) 2003 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */
#ifdef notdef
static	char sccsid[] = "@(#)file.c	4.12 (Berkeley) 11/17/85";
#endif
/*
 * file - determine type of file
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <libc.h>
#include <gnu/a.out.h>
#include <mach-o/loader.h>
#include <mach-o/fat.h>
#include "stuff/arch.h"
#define NIL 0
extern int	errno;
extern int	sys_nerr;
#ifdef __OPENSTEP__
extern char	*sys_errlist[];
#endif
int in;
int i  = 0;
char buf[BUFSIZ];
char arch_buf[BUFSIZ];
char *troff[] = {	/* new troff intermediate lang */
	"x","T","res","init","font","202","V0","p1",0};
char *fort[] = {
	"function","subroutine","common","dimension","block","integer",
	"real","data","double",0};
char *asc[] = {
	"chmk","mov","tst","clr","jmp",0};
char *c[] = {
	"int","char","float","double","struct","extern",0};
char *as[] = {
	"globl","byte","align","text","data","comm",0};
char *sh[] = {
	"fi", "elif", "esac", "done", "export",
	"readonly", "trap", "PATH", "HOME", 0 };
char *csh[] = {
	"alias", "breaksw", "endsw", "foreach", "limit",  "onintr",
	"repeat", "setenv", "source", "path", "home", 0 };
int	ifile;

static void type(
    char *file);

static void print_arch_name_for_file(
    cpu_type_t cputype,
    cpu_subtype_t cpusubtype);

static void type_buf(
    int print_arch_name);

static int oldo(
    char *cp);

static int troffint(
    char *bp,
    int n);

static int lookup(
    char **tab);

static int ccom(
    void);

static int ascom(
    void);

static int english(
    unsigned char *bp,
    int n);

static int shellscript(
    char *buf,
    struct stat *sb);

static int shell(
    char *bp,
    int n,
    char **tab);

char *progname = NULL;

void
main(
int argc,
char **argv,
char **envp)
{
	FILE *fl;
	register char *p;
	char ap[MAXPATHLEN + 1];

	progname = argv[0];
	if (argc < 2) {
		fprintf(stderr, "usage: %s file ...\n", argv[0]);
		exit(3);
	}
		
	if (argc>1 && argv[1][0]=='-' && argv[1][1]=='f') {
		if ((fl = fopen(argv[2], "r")) == NULL) {
			perror(argv[2]);
			exit(2);
		}
		while ((p = fgets(ap, sizeof ap, fl)) != NULL) {
			int l = strlen(p);
			if (l>0)
				p[l-1] = '\0';
			printf("%s:	", p);
			type(p);
			if (ifile>=0)
				close(ifile);
		}
		exit(1);
	}
	while(argc > 1) {
		printf("%s:	", argv[1]);
		type(argv[1]);
		fflush(stdout);
		argc--;
		argv++;
		if (ifile >= 0)
			close(ifile);
	}
	exit(0);
}

static struct stat mbuf;

static
void
type(
char *file)
{
    int j;
    char slink[MAXPATHLEN + 1];
    unsigned long i, magic, size;
    struct fat_header fat_header;
    struct fat_arch *fat_archs;

	ifile = -1;
	if (lstat(file, &mbuf) < 0) {
		printf("%s\n",
		(unsigned)errno < sys_nerr? sys_errlist[errno]: "Cannot stat");
		return;
	}
	switch (mbuf.st_mode & S_IFMT) {

	case S_IFLNK:
		printf("symbolic link");
		j = readlink(file, slink, sizeof slink - 1);
		if (j >= 0) {
			slink[j] = '\0';
			printf(" to %s", slink);
		}
		printf("\n");
		return;

	case S_IFDIR:
		if (mbuf.st_mode & S_ISVTX)
			printf("append-only ");
		printf("directory\n");
		return;

	case S_IFCHR:
	case S_IFBLK:
		printf("%s special (%d/%d)\n",
		    (mbuf.st_mode&S_IFMT) == S_IFCHR ? "character" : "block",
		     major(mbuf.st_rdev), minor(mbuf.st_rdev));
		return;

	case S_IFSOCK:
		printf("socket\n");
		return;
	}

	ifile = open(file, 0);
	if(ifile < 0) {
		printf("%s\n",
		(unsigned)errno < sys_nerr? sys_errlist[errno]: "Cannot read");
		return;
	}
	in = read(ifile, buf, BUFSIZ);
	if(in == 0){
		printf("empty\n");
		return;
	}

	size = in;
	memcpy(&magic, buf, sizeof(unsigned long));
#ifdef __BIG_ENDIAN__
	if(size >= sizeof(unsigned long) && magic == FAT_MAGIC)
#endif /* __BIG_ENDIAN__ */
#ifdef __LITTLE_ENDIAN__
	if(size >= sizeof(unsigned long) && SWAP_LONG(magic) == FAT_MAGIC)
#endif /* __LITTLE_ENDIAN__ */
	{
	    if(size < sizeof(struct fat_header)){
		printf("truncated fat file\n");
		return;
	    }
	    memcpy(&fat_header, buf, sizeof(struct fat_header));
#ifdef __LITTLE_ENDIAN__
	    swap_fat_header(&fat_header, LITTLE_ENDIAN_BYTE_SEX);
#endif /* __LITTLE_ENDIAN__ */
	    if(sizeof(struct fat_header) + fat_header.nfat_arch *
	       sizeof(struct fat_arch) > size){
		printf("truncated fat file\n");
		return;
	    }
	    memcpy(arch_buf, buf + sizeof(struct fat_header),
		   fat_header.nfat_arch * sizeof(struct fat_arch));
	    fat_archs = (struct fat_arch *)(arch_buf);
#ifdef __LITTLE_ENDIAN__
	    swap_fat_arch(fat_archs, fat_header.nfat_arch,
			  LITTLE_ENDIAN_BYTE_SEX);
#endif /* __LITTLE_ENDIAN__ */
	    printf("fat file with %lu architecture(s)\n", fat_header.nfat_arch);
	    for(i = 0; i < fat_header.nfat_arch; i++){
		printf("%s", file);
		print_arch_name_for_file(fat_archs[i].cputype,
					 fat_archs[i].cpusubtype);
		printf(":\t");
		lseek(ifile, fat_archs[i].offset, L_SET);
		in = read(ifile, buf, BUFSIZ);
		if(in == -1 || in == 0)
		    printf("malformed fat file for this architecture\n");
		else
		    type_buf(FALSE);
	    }
	}
	else
	    type_buf(TRUE);
}

static
void
print_arch_name_for_file(
cpu_type_t cputype,
cpu_subtype_t cpusubtype)
{
    const struct arch_flag *arch_flag;

	arch_flag = get_arch_flags();
	while(arch_flag->name != NULL){
	    if(arch_flag->cputype == cputype &&
	       arch_flag->cpusubtype == cpusubtype){
		printf(" (for architecture %s)", arch_flag->name);
		return;
	    }
	    arch_flag++;
	}
	printf(" (for architecture cputype (%d) cpusubtype (%d))",
	       cputype, cpusubtype);
}

static
void
type_buf(
int print_arch_name)
{
    int j,nl;
    char ch;
    struct mach_header *mhp;
    struct load_command *lcp, l;
    struct symtab_command *stp;
    unsigned long magic;
    enum bool swapped;
    enum byte_sex host_byte_sex;

	host_byte_sex = get_host_byte_sex();

	magic = *(int *)buf;
	switch(magic) {

	case 0000413:
		printf("old sun-2 demand paged ");
		goto exec;
	case 0200413:
		printf("mc68010 demand paged ");
		goto exec;
	case 0400413:
		printf("mc68020 demand paged ");
		goto exec;

	case 0000410:
		printf("old sun-2 pure ");
		goto exec;
	case 0200410:
		printf("mc68010 pure ");
		goto exec;
	case 0400410:
		printf("mc68020 pure ");
		goto exec;

	case 0411:
		printf("jfr or pdp-11 unix 411 executable\n");
		return;

	case 0000407:
		printf("old sun-2 ");
		goto exec;
	case 0200407:
		printf("mc68010 ");
		goto exec;
	case 0400407:
		printf("mc68020 ");
		goto exec;
exec:
		if (mbuf.st_mode & S_ISUID)
			printf("set-uid ");
		if (mbuf.st_mode & S_ISGID)
			printf("set-gid ");
		if (mbuf.st_mode & S_ISVTX)
			printf("sticky ");
		printf("executable");
		if(((int *)buf)[4] != 0) {
			printf(" not stripped");
			if(oldo(buf))
				printf(" (old format symbol table)");
		}
		printf("\n");
		return;

	case MH_MAGIC:
	case SWAP_LONG(MH_MAGIC):
		if (mbuf.st_mode & S_ISUID)
			printf("set-uid ");
		if (mbuf.st_mode & S_ISGID)
			printf("set-gid ");
		if (mbuf.st_mode & S_ISVTX)
			printf("sticky ");
		switch(((int *)buf)[3]){
			case MH_OBJECT:
			case SWAP_LONG(MH_OBJECT):
			    printf("Mach-O relocatable");
			    break;
			case MH_EXECUTE:
			case SWAP_LONG(MH_EXECUTE):
			    printf("Mach-O executable");
			    break;
			case MH_FVMLIB:
			case SWAP_LONG(MH_FVMLIB):
			    printf("Mach-O fixed virtual memory shared library");
			    break;
			case MH_DYLIB:
			case SWAP_LONG(MH_DYLIB):
			    printf("Mach-O dynamically linked shared library");
			    break;
			case MH_DYLIB_STUB:
			case SWAP_LONG(MH_DYLIB_STUB):
			    printf("Mach-O dynamically linked shared library "
				   "stub");
			    break;
			case MH_DYLINKER:
			case SWAP_LONG(MH_DYLINKER):
			    printf("Mach-O dynamic linker");
			    break;
			case MH_BUNDLE:
			case SWAP_LONG(MH_BUNDLE):
			    printf("Mach-O bundle");
			    break;
			case MH_CORE:
			case SWAP_LONG(MH_CORE):
			    printf("Mach-O core file\n");
			    return;
			case MH_PRELOAD:
			case SWAP_LONG(MH_PRELOAD):
			    printf("Mach-O preloaded file\n");
			    return;
			default:
			    printf("Mach-O object file of unknown type\n");
			    return;
		}
		if(magic == SWAP_LONG(MH_MAGIC))
		    swapped = TRUE;
		else
		    swapped = FALSE;
		mhp = (struct mach_header *)buf;
		if(swapped)
		    swap_mach_header(mhp, host_byte_sex);
		if(print_arch_name == TRUE)
		    print_arch_name_for_file(mhp->cputype, mhp->cpusubtype);
		lcp = (struct load_command *)(buf + sizeof(struct mach_header));
		stp = NIL;
		for (i = 0; i < mhp->ncmds; i++){
			l = *lcp;
			if(swapped)
			    swap_load_command(&l, host_byte_sex);
			if(((char *)lcp + l.cmdsize) >= (&buf[0] + BUFSIZ))
				break;
			if(stp == NIL && l.cmd == LC_SYMTAB){
				stp = (struct symtab_command *)lcp;
				if(swapped)
				    swap_symtab_command(stp, host_byte_sex);
				break;
			}
			lcp = (struct load_command *)
				((char *)lcp + l.cmdsize);
		}
		if(stp != NIL && stp->nsyms != 0)
			printf(" not stripped");
		printf("\n");
		return;

	case 0177555:
		printf("very old archive\n");
		return;

	case 0177545:
		printf("old archive\n");
		return;

	case 070707:
		printf("cpio data\n");
		return;
	}

	if (buf[0] == '#' && buf[1] == '!' && shellscript(buf+2, &mbuf))
		return;
	if (buf[0] == '\037' && buf[1] == '\235') {
		if (buf[2]&0x80)
			printf("block ");
		printf("compressed %d bit code data\n", buf[2]&0x1f);
		return;
	}
	if(strncmp(buf, "!<arch>\n__.SYMDEF", 17) == 0 ) {
		printf("archive random library\n");
		return;
	}
	if (strncmp(buf, "!<arch>\n", 8)==0) {
		printf("archive\n");
		return;
	}
	if (mbuf.st_size % 512 == 0) {	/* it may be a PRESS file */
		lseek(ifile, -512L, 2);	/* last block */
		if (read(ifile, buf, BUFSIZ) > 0 && *(short *)buf == 12138) {
			printf("PRESS file\n");
			return;
		}
	}
	i = 0;
	if(ccom() == 0)goto notc;
	while(buf[i] == '#'){
		j = i;
		while(buf[i++] != '\n'){
			if(i - j > 255){
				printf("data\n"); 
				return;
			}
			if(i >= in)goto notc;
		}
		if(ccom() == 0)goto notc;
	}
check:
	if(lookup(c) == 1){
		while((ch = buf[i++]) != ';' && ch != '{')if(i >= in)goto notc;
		printf("c program text");
		goto outa;
	}
	nl = 0;
	while(buf[i] != '('){
		if(buf[i] <= 0)
			goto notas;
		if(buf[i] == ';'){
			i++; 
			goto check; 
		}
		if(buf[i++] == '\n')
			if(nl++ > 6)goto notc;
		if(i >= in)goto notc;
	}
	while(buf[i] != ')'){
		if(buf[i++] == '\n')
			if(nl++ > 6)goto notc;
		if(i >= in)goto notc;
	}
	while(buf[i] != '{'){
		if(buf[i++] == '\n')
			if(nl++ > 6)goto notc;
		if(i >= in)goto notc;
	}
	printf("c program text");
	goto outa;
notc:
	i = 0;
	while(buf[i] == 'c' || buf[i] == '#'){
		while(buf[i++] != '\n')if(i >= in)goto notfort;
	}
	if(lookup(fort) == 1){
		printf("fortran program text");
		goto outa;
	}
notfort:
	i=0;
	if(ascom() == 0)goto notas;
	j = i-1;
	if(buf[i] == '.'){
		i++;
		if(lookup(as) == 1){
			printf("assembler program text"); 
			goto outa;
		}
		else if(buf[j] == '\n' && isalpha(buf[j+2])){
			printf("roff, nroff, or eqn input text");
			goto outa;
		}
	}
	while(lookup(asc) == 0){
		if(ascom() == 0)goto notas;
		while(buf[i] != '\n' && buf[i++] != ':')
			if(i >= in)goto notas;
		while(buf[i] == '\n' || buf[i] == ' ' || buf[i] == '\t')if(i++ >= in)goto notas;
		j = i-1;
		if(buf[i] == '.'){
			i++;
			if(lookup(as) == 1){
				printf("assembler program text"); 
				goto outa; 
			}
			else if(buf[j] == '\n' && isalpha(buf[j+2])){
				printf("roff, nroff, or eqn input text");
				goto outa;
			}
		}
	}
	printf("assembler program text");
	goto outa;
notas:
	for(i=0; i < in; i++)if(buf[i]&0200){
		if (buf[0]=='\100' && buf[1]=='\357')
			printf("troff (CAT) output\n");
		else
			printf("data\n"); 
		return;
	}
	if (mbuf.st_mode&((S_IEXEC)|(S_IEXEC>>3)|(S_IEXEC>>6))) {
		if (mbuf.st_mode & S_ISUID)
			printf("set-uid ");
		if (mbuf.st_mode & S_ISGID)
			printf("set-gid ");
		if (mbuf.st_mode & S_ISVTX)
			printf("sticky ");
		if (shell(buf, in, sh))
			printf("shell script");
		else if (shell(buf, in, csh))
			printf("c-shell script");
		else
			printf("commands text");
	} else if (troffint(buf, in))
		printf("troff intermediate output text");
	else if (shell(buf, in, sh))
		printf("shell commands");
	else if (shell(buf, in, csh))
		printf("c-shell commands");
	else if (english(buf, in))
		printf("English text");
	else
		printf("ascii text");
outa:
	while(i < in)
		if((buf[i++]&0377) > 127){
			printf(" with garbage\n");
			return;
		}
	/* if next few lines in then read whole file looking for nulls ...
		while((in = read(ifile,buf,BUFSIZ)) > 0)
			for(i = 0; i < in; i++)
				if((buf[i]&0377) > 127){
					printf(" with garbage\n");
					return;
				}
		.... */
	printf("\n");
}

static
int
oldo(
char *cp)
{
	struct exec ex;
	struct stat stb;

	ex = *(struct exec *)cp;
	if (fstat(ifile, &stb) < 0)
		return(0);
	if (N_STROFF(ex)+sizeof(off_t) > stb.st_size)
		return (1);
	return (0);
}

static
int
troffint(
char *bp,
int n)
{
	int k;

	i = 0;
	for (k = 0; k < 6; k++) {
		if (lookup(troff) == 0)
			return(0);
		if (lookup(troff) == 0)
			return(0);
		while (i < n && buf[i] != '\n')
			i++;
		if (i++ >= n)
			return(0);
	}
	return(1);
}

static
int
lookup(
char **tab)
{
	char r;
	int k,j,l;
	while(buf[i] == ' ' || buf[i] == '\t' || buf[i] == '\n')i++;
	for(j=0; tab[j] != 0; j++){
		l=0;
		for(k=i; ((r=tab[j][l++]) == buf[k] && r != '\0');k++);
		if(r == '\0')
			if(buf[k] == ' ' || buf[k] == '\n' || buf[k] == '\t'
			    || buf[k] == '{' || buf[k] == '/'){
				i=k;
				return(1);
			}
	}
	return(0);
}

static
int
ccom(void)
{
	char cc;
	while((cc = buf[i]) == ' ' || cc == '\t' || cc == '\n')if(i++ >= in)return(0);
	if(buf[i] == '/' && buf[i+1] == '*'){
		i += 2;
		while(buf[i] != '*' || buf[i+1] != '/'){
			if(buf[i] == '\\')i += 2;
			else i++;
			if(i >= in)return(0);
		}
		if((i += 2) >= in)return(0);
	}
	if(buf[i] == '\n')if(ccom() == 0)return(0);
	return(1);
}

static
int
ascom(void)
{
	while(buf[i] == '/'){
		i++;
		while(buf[i++] != '\n')if(i >= in)return(0);
		while(buf[i] == '\n')if(i++ >= in)return(0);
	}
	return(1);
}

static
int
english(
unsigned char *bp,
int n)
{
# define NASC 128
	int ct[NASC], j, vow, freq, rare;
	int badpun = 0, punct = 0;
	if (n<50) return(0); /* no point in statistics on squibs */
	for(j=0; j<NASC; j++)
		ct[j]=0;
	for(j=0; j<n; j++)
	{
		if (bp[j]<NASC)
			ct[bp[j]|040]++;
		switch (bp[j])
		{
		case '.': 
		case ',': 
		case ')': 
		case '%':
		case ';': 
		case ':': 
		case '?':
			punct++;
			if ( j < n-1 &&
			    bp[j+1] != ' ' &&
			    bp[j+1] != '\n')
				badpun++;
		}
	}
	if (badpun*5 > punct)
		return(0);
	vow = ct['a'] + ct['e'] + ct['i'] + ct['o'] + ct['u'];
	freq = ct['e'] + ct['t'] + ct['a'] + ct['i'] + ct['o'] + ct['n'];
	rare = ct['v'] + ct['j'] + ct['k'] + ct['q'] + ct['x'] + ct['z'];
	if (2*ct[';'] > ct['e']) return(0);
	if ( (ct['>']+ct['<']+ct['/'])>ct['e']) return(0); /* shell file test */
	return (vow*5 >= n-ct[' '] && freq >= 10*rare);
}

static
int
shellscript(
char *buf,
struct stat *sb)
{
	register char *tp;
	char *cp, *xp;

	cp = index(buf, '\n');
	if (cp == 0 || cp - buf > in)
		return (0);
	for (tp = buf; tp != cp && isspace(*tp); tp++)
		if (!isascii(*tp))
			return (0);
	for (xp = tp; tp != cp && !isspace(*tp); tp++)
		if (!isascii(*tp))
			return (0);
	if (tp == xp)
		return (0);
	if (sb->st_mode & S_ISUID)
		printf("set-uid ");
	if (sb->st_mode & S_ISGID)
		printf("set-gid ");
	if (strncmp(xp, "/bin/sh", tp-xp) == 0)
		xp = "shell";
	else if (strncmp(xp, "/bin/csh", tp-xp) == 0)
		xp = "c-shell";
	else
		*tp = '\0';
	printf("executable %s script\n", xp);
	return (1);
}

static
int
shell(
char *bp,
int n,
char **tab)
{

	i = 0;
	do {
		if (buf[i] == '#' || buf[i] == ':')
			while (i < n && buf[i] != '\n')
				i++;
		if (++i >= n)
			break;
		if (lookup(tab) == 1)
			return (1);
	} while (i < n);
	return (0);
}
