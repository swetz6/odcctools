

void __attribute__((visibility("hidden"))) foo()
{
}
