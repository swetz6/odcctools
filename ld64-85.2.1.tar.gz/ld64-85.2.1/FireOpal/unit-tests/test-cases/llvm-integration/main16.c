
int tent;
int global = 5;

int foo() { return tent + global; }

int main() { foo(); return 0; }

