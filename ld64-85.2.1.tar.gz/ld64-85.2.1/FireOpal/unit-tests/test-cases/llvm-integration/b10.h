struct my_struct
{
  void (*f)(void);
};

extern struct my_struct my_hooks;
