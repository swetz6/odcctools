enum E
  {
    ZERO,
    ONE
  };
    
extern enum E e[1000];
extern void foo(void);
