

void collisionChecker()  { }


int __attribute__((weak)) foo() 
{ 
	collisionChecker();
	return 1; 
}



