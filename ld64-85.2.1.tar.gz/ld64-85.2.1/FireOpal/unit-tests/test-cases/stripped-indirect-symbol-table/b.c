
int bData = 0;

void b()
{
	++bData;
}

void bb()
{
	++bData;
}
