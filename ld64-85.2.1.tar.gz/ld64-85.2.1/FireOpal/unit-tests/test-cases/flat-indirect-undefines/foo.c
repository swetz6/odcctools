
extern void bar();

void foo()
{
	bar();
}

