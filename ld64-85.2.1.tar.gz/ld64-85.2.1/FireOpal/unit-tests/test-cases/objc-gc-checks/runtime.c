void _objc_empty_cache() {}
void _objc_empty_vtable() {}
