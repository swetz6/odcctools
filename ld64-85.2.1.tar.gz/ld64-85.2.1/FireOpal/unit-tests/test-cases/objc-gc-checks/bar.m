
@interface Bar  {
	int f;
}
- (void) doit;
@end

@implementation Bar
- (void) doit { }
@end

