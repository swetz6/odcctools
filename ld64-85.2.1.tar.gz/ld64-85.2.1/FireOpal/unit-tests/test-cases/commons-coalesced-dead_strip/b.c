#include "c.h"

float bb() { return bar; }

