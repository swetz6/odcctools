

__attribute__((visibility("hidden"))) void foo() 
{
   // do nothing
}
