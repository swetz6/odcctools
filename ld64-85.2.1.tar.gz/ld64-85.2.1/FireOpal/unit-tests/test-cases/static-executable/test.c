
int foo()
{
	return 0;
}


int entry()
{
	return foo();
}
