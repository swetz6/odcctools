#include <Foundation/Foundation.h>


NSString* other()
{
	return [NSString stringWithUTF8String:"hello"];
}
