#include "foo.h"

int data4;		// foo.c also has weak_import uninitialized

