

void __attribute__((weak,visibility("hidden"))) foo()
{

}


void bar()
{
}
