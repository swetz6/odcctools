
int var;

int main()
{
	var = 3;
	return 0;
}
