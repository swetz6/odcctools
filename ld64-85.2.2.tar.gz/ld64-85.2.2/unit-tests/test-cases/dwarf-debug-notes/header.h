

inline int foo(int x) 
{ 
	return x + 10;
}

extern int bar(int x);