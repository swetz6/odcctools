void foo() { }
