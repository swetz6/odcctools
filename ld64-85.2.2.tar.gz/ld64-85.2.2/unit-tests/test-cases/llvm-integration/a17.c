
int a = 0;
int func_a() { return a; }

