
int foo1()
{
  return 42;
}

int foo2()
{
  return 21;
}
