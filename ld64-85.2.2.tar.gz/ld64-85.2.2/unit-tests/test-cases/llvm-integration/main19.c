extern int foo();

int main()
{
	foo();
	return 0;
}

