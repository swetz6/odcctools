
int aaa() 
{
	return 1;
}

